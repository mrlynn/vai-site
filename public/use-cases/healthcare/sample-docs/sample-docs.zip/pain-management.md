# Pain Management Protocol

**Document ID:** CG-PAIN-2025-001
**Effective Date:** January 1, 2025
**Department:** Anesthesiology / Internal Medicine
**Classification:** Clinical Guideline

## 1. Pain Assessment

Assess pain at every encounter using a validated tool appropriate to the patient:

**Numeric Rating Scale (NRS):** 0 to 10 scale for patients who can self-report. 0 = no pain, 1 to 3 = mild, 4 to 6 = moderate, 7 to 10 = severe.

**Wong-Baker FACES Scale:** For patients with language barriers or difficulty with numeric scales. Six faces ranging from smiling (no hurt) to crying (hurts worst).

**Behavioral Pain Scale (BPS):** For non-communicative or sedated patients. Assesses facial expression, upper limb movement, and ventilator compliance.

Document pain location, quality, duration, aggravating/alleviating factors, and functional impact in addition to the numeric score.

## 2. Multimodal Approach

Multimodal analgesia is the standard of care. Combining agents with different mechanisms of action provides superior pain relief with lower doses and fewer side effects than any single agent alone.

**Principles:**
- Use non-opioid analgesics as the foundation
- Add opioids only when non-opioid therapies are insufficient
- Incorporate non-pharmacologic interventions at every level
- Set realistic pain goals (functional improvement, not necessarily zero pain)

## 3. Acute Pain Management

### 3.1 Mild Pain (NRS 1 to 3)

**First-line:** Acetaminophen 650 to 1,000 mg every 6 hours (maximum 3,000 mg/day in adults; 2,000 mg/day if liver disease or regular alcohol use).

**Add or substitute:** Ibuprofen 400 to 600 mg every 6 hours or naproxen 250 to 500 mg every 12 hours (with food; avoid in CKD, active GI bleeding, heart failure, or concurrent anticoagulation).

**Non-pharmacologic:** Ice/heat, elevation, positioning, relaxation techniques.

### 3.2 Moderate Pain (NRS 4 to 6)

**Scheduled:** Acetaminophen plus NSAID (alternating schedule provides near-continuous coverage).

**Add:** Tramadol 50 to 100 mg every 6 hours (caution: seizure risk, serotonin syndrome risk with SSRIs, avoid in severe renal/hepatic impairment).

**Consider:** Regional anesthesia (nerve blocks, local anesthetic infiltration) for surgical and procedural pain.

### 3.3 Severe Pain (NRS 7 to 10)

**Opioid therapy:** Oxycodone 5 to 10 mg every 4 to 6 hours PRN, or morphine 2 to 4 mg IV every 2 to 4 hours PRN. Use the lowest effective dose for the shortest duration.

**Continue:** Non-opioid foundation (acetaminophen, NSAID if not contraindicated).

**Consider:** PCA (patient-controlled analgesia) for post-surgical pain. Epidural analgesia for major abdominal or thoracic procedures.

## 4. Chronic Pain Management

### 4.1 Non-Pharmacologic Interventions

Incorporate as first-line for chronic pain: physical therapy, cognitive behavioral therapy (CBT), mindfulness-based stress reduction, acupuncture (evidence supports for chronic low back pain, knee OA, headaches), exercise programs (graded activity), TENS (transcutaneous electrical nerve stimulation).

### 4.2 Neuropathic Pain Agents

**First-line:** Gabapentin (start 100 to 300 mg at bedtime, titrate to 300 to 1,200 mg three times daily) or pregabalin (start 25 to 75 mg twice daily, titrate to 150 to 300 mg twice daily). Adjust for renal function.

**Alternative first-line:** Duloxetine 30 to 60 mg daily (also effective for diabetic neuropathy, fibromyalgia, and musculoskeletal pain). Avoid in severe hepatic impairment.

**Second-line:** Tricyclic antidepressants (amitriptyline 10 to 75 mg at bedtime). Use with caution in elderly due to anticholinergic effects.

**Topical options:** Lidocaine 5% patches (for localized neuropathic pain), capsaicin 8% patch (for post-herpetic neuralgia).

## 5. Opioid Stewardship

### 5.1 Prescribing Limits

**Acute pain (opioid-naive patients):** Maximum 3-day supply for post-ED discharge. Maximum 7-day supply for post-surgical discharge. No extended-release opioids for acute pain.

**Chronic pain:** Re-evaluate need at least every 3 months. Document functional goals and reassess whether opioid therapy is meeting them.

### 5.2 Risk Assessment

Before initiating opioid therapy for chronic pain:
- Check the state Prescription Drug Monitoring Program (PDMP)
- Screen for substance use disorder risk (ORT, SOAPP-R)
- Obtain urine drug screen at baseline and periodically
- Discuss risks and set expectations (pain contract/treatment agreement)
- Co-prescribe naloxone for patients on 50 MME/day or greater, or with concurrent benzodiazepine use, or with history of overdose

### 5.3 Tapering Protocol

When discontinuing opioid therapy: reduce by 10% to 25% of the total daily dose every 2 to 4 weeks. Slower tapers (5% to 10% per month) for patients on long-term therapy (greater than 1 year). Monitor for withdrawal symptoms, worsening pain, and psychological distress. Provide non-opioid analgesic alternatives and non-pharmacologic support during the taper.

## 6. Special Populations

**Elderly (age 65 and older):** Start at lower doses, titrate slowly. Avoid meperidine. Prefer acetaminophen as first-line. Use NSAIDs cautiously (renal, GI, cardiovascular risks).

**Renal impairment:** Avoid morphine (active metabolite accumulation). Prefer hydromorphone or fentanyl. Adjust gabapentin/pregabalin doses.

**Hepatic impairment:** Reduce acetaminophen to 2,000 mg/day maximum. Avoid tramadol. Use opioids cautiously with reduced initial doses.
